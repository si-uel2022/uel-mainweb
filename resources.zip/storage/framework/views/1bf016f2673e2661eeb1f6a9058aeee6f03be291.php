

<?php $__env->startSection('title', 'Admin'); ?>

<?php $__env->startSection('content'); ?>


<h1 class="text-center">Admin</h1>
<br><br><br>
<div class="row text-center">
    <div class="col-sm">
        
        <a href="/admin/showML" class="nav-btn">Show ML</a>
    </div>
    <div class="col-sm">
        <a href="/admin/showPUBG" class="nav-btn">Show PUBG</a>
    </div>
    <div class="col-sm">
        <a href="/admin/showValorant" class="nav-btn">Show Valorant</a>
    </div>
    <div class="col-sm">
        <a href="/admin/showBA" class="nav-btn">Show Brand Ambassador</a>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\UEL21-22\web\uel-mainweb\resources\views/admin/home.blade.php ENDPATH**/ ?>