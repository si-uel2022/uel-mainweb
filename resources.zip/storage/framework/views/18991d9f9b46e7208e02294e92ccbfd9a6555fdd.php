<!DOCTYPE html>
<html>

<head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="<?php echo e(asset('css/uel.css')); ?>">
</head>

<body style="background-color: #222222">
    <div class="body-gradient">

        <nav class="navbar navbar-expand-lg navbar-light">
            <a class="navbar-brand nav-text" href="#">
                <img src="<?php echo e(asset('images/logo-uel.png')); ?>" width="100" height="100" alt="Logo UEL">
            </a> 
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="<?php echo e(__('Toggle navigation')); ?>">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <!-- Left Side Of Navbar -->
                <ul class="navbar-nav mr-auto">

                </ul>

                <!-- Right Side Of Navbar -->
                <ul class="navbar-nav ml-auto">
                    <!-- Authentication Links -->
                    <?php if(auth()->guard()->guest()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                        </li>
                        <?php if(Route::has('register')): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                            </li>
                        <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre style="font-size: 44px; color: white;">
                                    <?php echo e(Auth::user()->name); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    
                                    <a class="dropdown-item" href="<?php echo e(route('admin')); ?>">
                                        Kembali ke dashboard
                                    </a>
                                    

                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                        class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                    <?php endif; ?>
                </ul>
            </div>
        </nav>

        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->yieldContent('scripts'); ?>
    </div>
    <div class="body-bottom">
        <div class="row">
            <div class="col-sm-2">
                <img src="<?php echo e(asset('images/logo-uel.png')); ?>" width="130" height="130" alt="Logo UEL">
            </div>
            <div class="col-sm-6">
                <p class="heading-white-text">UBAYA E-Sport League Season 2</p>
                <p class="subheading-white-text">Report Bugs and Problem: (email SI UEL disini)</p>
                <p class="subheading-white-text">Developed by Information System UEL 2022</p>
            </div>
            <div class="col-sm-4">
                <a href="https://www.instagram.com/uel2022_/"><img src="<?php echo e(asset('images/logo_ig.png')); ?>" width="75" height="75" alt="Instagram UEL"></a>
                <a href=""><img src="<?php echo e(asset('images/logo_youtube.png')); ?>" width="130" height="130" alt="Youtube UEL"></a>
            </div>
        </div>
    </div>
    
</body>

<script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>

</html>
<?php /**PATH D:\Kuliah\UEL21-22\web\uel-mainweb\resources\views/admin/layout.blade.php ENDPATH**/ ?>