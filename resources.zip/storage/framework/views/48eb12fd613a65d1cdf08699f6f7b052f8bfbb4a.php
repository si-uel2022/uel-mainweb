<p>Konfirmasi Pendaftaran Brand Ambassador</p>
<p>------</p>

<p>Terima kasih telah mendaftar di UEL 2022 sebagai Brand Ambassador, <?php echo e($user_nama); ?>!</p>

<p>Data Anda telah diproses oleh panitia dan statusnya dinyatakan ACCEPTED.</p>

<p>Mohon menunggu informasi selanjutnya dari pihak panitia. Terima kasih!</p>

<b>CP Registrasi UEL 2022: </b><br>
<b>line : oliviafrnsisca </b><br>
<b>wa  : 082233377746 </b><br>

<b><i>UEL 2022? Survive is good, thrive is better!</i></b><?php /**PATH D:\Kuliah\UEL21-22\web\uel-mainweb\resources\views/mail/EmailAcceptBA.blade.php ENDPATH**/ ?>