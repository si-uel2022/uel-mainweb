<div class="portlet">
    <h5><?php echo e($player->nama); ?></h5>
    <ul>
        <li>ID Server: <?php echo e($player->id_server); ?></li>
        <li>Nickname: <?php echo e($player->nickname); ?></li>
        <li>Hero: <?php echo e($player->hero); ?></li>
        <li>Role: <?php echo e($player->role); ?></li>
        <li>Device: <?php echo e($player->device); ?></li>
    </ul>

    <p style="text-align: center; font-weight: bold">Sertifikat Vaksin</p>
    <img style="display: block; margin-left: auto; margin-right: auto;" src="<?php echo e(asset('file_vaksin/'.$player->vaksin)); ?>" alt="" width="100px;"> <br>
    <p style="text-align: center; font-weight: bold">KTM</p>
    <img style="display: block; margin-left: auto; margin-right: auto;" src="<?php echo e(asset('file_ktm/'.$player->ktm)); ?>" alt="" width="100px;"> <br>
    <p style="text-align: center; font-weight: bold">Foto</p>
    <img style="display: block; margin-left: auto; margin-right: auto;" src="<?php echo e(asset('file_foto/'.$player->foto)); ?>" alt="" width="100px;">
</div><?php /**PATH D:\Kuliah\UEL21-22\web\uel-mainweb\resources\views/admin/detailModalML.blade.php ENDPATH**/ ?>