<div class="portlet">
    <h5><?php echo e($person->nama); ?></h5>
    <ul>
        <li>Tentang UEL: <?php echo e($person->tentang_uel); ?></li>
        <li>Komitmen: <?php echo e($person->komitmen); ?></li>
    </ul>

    <p style="text-align: center; font-weight: bold">KTM</p>
    <img style="display: block; margin-left: auto; margin-right: auto;" src="<?php echo e(asset('file_ktm/'.$person->ktm)); ?>" alt="" width="100px;">
</div><?php /**PATH D:\Kuliah\UEL21-22\web\uel-mainweb\resources\views/admin/detailModalBA.blade.php ENDPATH**/ ?>