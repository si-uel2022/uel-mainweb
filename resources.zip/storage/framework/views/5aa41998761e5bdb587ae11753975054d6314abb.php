<div class="portlet">
    <h5><?php echo e($player->nama); ?></h5>
    <ul>
        <li>ID Game: <?php echo e($player->id_game); ?></li>
        <li>Nick Game: <?php echo e($player->nick_game); ?></li>
        <li>Senjata: <?php echo e($player->senjata); ?></li>
        <li>Role: <?php echo e($player->role); ?></li>
        <li>Device: <?php echo e($player->device); ?></li>
    </ul>

    <p style="text-align: center; font-weight: bold">Sertifikat Vaksin</p>
    <img style="display: block; margin-left: auto; margin-right: auto;" src="<?php echo e(asset('file_vaksin/'.$tim->nama.'/'.$player->vaksin)); ?>" alt="" width="100px;"> <br>
    <p style="text-align: center; font-weight: bold">KTM</p>
    <img style="display: block; margin-left: auto; margin-right: auto;" src="<?php echo e(asset('file_ktm/'.$tim->nama.'/'.$player->ktm)); ?>" alt="" width="100px;"> <br>
    <p style="text-align: center; font-weight: bold">Foto</p>
    <img style="display: block; margin-left: auto; margin-right: auto;" src="<?php echo e(asset('file_foto/'.$tim->nama.'/'.$player->foto)); ?>" alt="" width="100px;">
</div><?php /**PATH D:\Kuliah\UEL21-22\web\uel-mainweb\resources\views/admin/detailModalPUBG.blade.php ENDPATH**/ ?>