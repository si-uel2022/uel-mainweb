

<?php $__env->startSection("content"); ?>
    <h1>about us</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("main.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\UEL21-22\web\uel-mainweb\resources\views/main/aboutus.blade.php ENDPATH**/ ?>