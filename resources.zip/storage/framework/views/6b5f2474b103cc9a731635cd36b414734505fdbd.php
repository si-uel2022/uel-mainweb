

<?php $__env->startSection('title', 'Admin'); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('status_accept')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('status_accept')); ?>

</div>
<?php endif; ?>

<?php if(session('status_reject')): ?>
<div class="alert alert-danger" role="alert">
    <?php echo e(session('status_reject')); ?>

</div>
<?php endif; ?>

<h1>Tim Mobile Legend</h1><br>

<div class="table-responsive">
    <table id="table" class="display" style="width:100%">
        <thead>
        <tr align="center" style="color: white">
            <th>No</th>
            <th>Nama Tim</th>
            <th>Status</th>
            <th>List Player</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $tim; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr align="center">
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($t->nama); ?></td>
                <td><?php echo e($t->status); ?></td>
                <td> <a href="<?php echo e(route('admin.showPlayerML',$t->id)); ?>">Show</a> </td>
                <td> 
                    <a href="<?php echo e(url('admin/acceptTimML/' . $t->id)); ?>" class="btn btn-info">Accept</a>
                    <a href="<?php echo e(url('admin/rejectTimML/' . $t->id)); ?>" class="btn btn-danger">Reject</a> 
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready( function () {
        $('#table').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\UEL21-22\web\uel-mainweb\resources\views/admin/adminML.blade.php ENDPATH**/ ?>