<p>Terima kasih telah mendaftar di UEL 2022, tim <?php echo e($user_tim); ?> ! </p>

<p>Data dari tim <?php echo e($user_tim); ?> telah diterima dan akan diproses oleh panitia.</p>
<p>Mohon menunggu untuk konfirmasi selanjutnya dari panitia! Terima kasih.</p>

<b><i>UEL 2022? Survive is good, thrive is better!</i></b><?php /**PATH D:\Kuliah\UEL21-22\web\uel-mainweb\resources\views/mail/EmailSubmit.blade.php ENDPATH**/ ?>