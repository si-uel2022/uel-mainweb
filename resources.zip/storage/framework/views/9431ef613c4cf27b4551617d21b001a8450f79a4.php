

<?php $__env->startSection('title', 'Admin'); ?>

<?php $__env->startSection('content'); ?>
<table id="table" class="display" style="width:100%">
    <thead>
    <tr align="center" style="color: white">
        <th>No</th>
        <th>Nama</th>
        <th>NRP</th>
        <th>Fakultas</th>
        <th>Angkatan</th>
        <th>ID Line</th>
        <th>No WA</th>
        <th>Instagram</th>
        <th>Domisili</th>
        <th>Sebagai</th>
        <th>Detail Player</th>
    </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $player; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr align="center">
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($p->nama); ?></td>
            <td><?php echo e($p->nrp); ?></td>
            <td><?php echo e($p->fakultas); ?></td>
            <td><?php echo e($p->angkatan); ?></td>
            <td><?php echo e($p->id_line); ?></td>
            <td><?php echo e($p->nomor); ?></td>
            <td><?php echo e($p->instagram); ?></td>
            <td><?php echo e($p->sebagai); ?></td>
            <td><?php echo e($p->domisili); ?></td>
            <td>
                <a href="#modal_player" class="btn btn-primary" data-toggle="modal" onclick="getData(<?php echo e($p->id); ?>);">
                    Detail Player
                </a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<div class="modal fade" id="modal_player" tabindex="-1" role="basic" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Detail Player</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">x</span>
                    </button>
            </div>
            <div class="modal-body" id="isi_modal_player">
                Player
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready( function () {
        $('#table').DataTable();
    });

    function getData(id) 
    {
        $.ajax({
			type:'POST',
			url:'<?php echo e(route("admin.showDetailML")); ?>',
			data:'_token= <?php echo csrf_token() ?> &id='+id,
			success:function(data) {
				$("#isi_modal_player").html(data.msg);
			}
		});
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\UEL21-22\web\uel-mainweb\resources\views/admin/timML.blade.php ENDPATH**/ ?>