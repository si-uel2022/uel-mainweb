

<?php $__env->startSection('title', 'Admin'); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('status_accept')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('status_accept')); ?>

</div>
<?php endif; ?>

<?php if(session('status_reject')): ?>
<div class="alert alert-danger" role="alert">
    <?php echo e(session('status_reject')); ?>

</div>
<?php endif; ?>

<h1>Brand Ambassador</h1><br>

<div class="table-responsive">
    <table id="table" class="display" style="width:100%">
        <thead>
        <tr align="center" style="color: white">
            <th>No</th>
            <th>Nama</th>
            <th>NRP</th>
            <th>Email</th>
            <th>Line</th>
            <th>WhatsApp</th>
            <th>Instagram</th>
            <th>Status</th>
            <th>Download</th>
            <th>Action</th>
            <th>Detail</th>
        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $ba; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr align="center">
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($b->nama); ?></td>
                <td><?php echo e($b->nrp); ?></td>
                <td><?php echo e($b->email); ?></td>
                <td><?php echo e($b->line); ?></td>
                <td><?php echo e($b->whatsapp); ?></td>
                <td><?php echo e($b->instagram); ?></td>
                <td><?php echo e($b->status); ?></td>
                <td>
                    <a href="<?php echo e(url('admin/downloadPorto/' . $b->id)); ?>" class="btn btn-primary"><i class="fa fa-pencil-square-o"></i> Portofolio</a>
                    <a href="<?php echo e(url('admin/downloadBA/' . $b->id)); ?>" class="btn btn-primary"><i class="fa fa-picture-o"></i> Foto</a>
                </td>
                <td>
                    <a href="<?php echo e(url('admin/acceptBA/' . $b->id)); ?>" class="btn btn-info">Accept <i class="fa fa-check"></i></a>
                    <a href="<?php echo e(url('admin/rejectBA/' . $b->id)); ?>" class="btn btn-danger">Reject <i class="fa fa-close"></i></a>
                </td>
                <td> 
                    <a href="#modal_detail" class="btn btn-primary" data-toggle="modal" onclick="getData(<?php echo e($b->id); ?>);">
                        Detail
                    </a> 
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<div class="modal fade" id="modal_detail" tabindex="-1" role="basic" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Detail Brand Ambassador</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">x</span>
                    </button>
            </div>
            <div class="modal-body" id="isi_modal_detail">
                BA
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready( function () {
        $('#table').DataTable();
    });

    function getData(id) 
    {
        $.ajax({
			type:'POST',
			url:'<?php echo e(route("admin.showDetailBA")); ?>',
			data:'_token= <?php echo csrf_token() ?> &id='+id,
			success:function(data) {
				$("#isi_modal_detail").html(data.msg);
			}
		});
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\UEL21-22\web\uel-mainweb\resources\views/admin/adminBA.blade.php ENDPATH**/ ?>