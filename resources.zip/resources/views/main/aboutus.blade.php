@extends("main.layout")

@section("content")
    <h1>about us</h1>
@endsection