@extends("main.layout")

@section("content")
    <h1>faq</h1>
@endsection