<p>Konfirmasi Pendaftaran Brand Ambassador</p>
<p>------</p>

<p>Terima kasih telah mendaftar di UEL 2022 sebagai Official & Player, {{$user_nama}}!</p>

<p>Data Anda telah diproses oleh panitia dan statusnya dinyatakan REJECTED.</p>

<p>Mohon menunggu informasi selanjutnya dari pihak panitia. Terima kasih</p>

<b>CP Registrasi UEL 2022:</b><br>
<b>line : oliviafrnsisca</b><br>
<b>wa : 082233377746</b><br>

<b><i>UEL 2022? Survive is good, thrive is better!</i></b>